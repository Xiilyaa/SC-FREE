/*
   * WaveCloudx Beta
   * Created By Catozolala
*/
/*
   • No enc? silahkan beli di wa.me/+6281938830020
   • Jangan di jual beli yak
*/


global.crypto = require("crypto") 
//==============================================  
global.botname = 'Xiilya Bot - MD'//nama bot nya
global.ownername = "Yudhaa"//nama owner lo
global.wm = "By Yudha - Dev"//wm gw ubah aja
global.owner = [
  "6288223954794" 
]
global.owner0 = '6288223954794@s.whatsapp.net'
global.anuwm = '🌊 Xiilyaa | Project'
//==============================================
global.owner1 = '6288223954794'
//==============================================
global.prefa = ['','!','.','🐦','🐤','🗿'] // jangan fi ubah
global.premium = ['6288223954794'] //premium ganti ae
global.listsc = ['6288223954794'] //serah
global.sessionName = 'session' //jangan di ubah 
//==============================================
global.thumb = "https://telegra.ph/file/499006925a493a48beca4.jpg"
global.thumbnail = "https://telegra.ph/file/71f30513756bbab19533c.jpg"
global.gamBar = [
 'https://telegra.ph/file/b311e2b1db248ebf85e09.jpg',
 'https://telegra.ph/file/c5f04994786190c3b2c7f.jpg',
 'https://telegra.ph/file/499006925a493a48beca4.jpg',
 'https://telegra.ph/file/71f30513756bbab19533c.jpg',
 'https://telegra.ph/file/791b6c9d74bee25a1b551.jpg'
 ]
 global.anime = "https://telegra.ph/file/897879e5e0cd09c251175.jpg"
 global.url = "https://whatsapp.com/channel/0029VaMMxs4L2AU78fsqk51A"
 global.blueAr = "https://telegra.ph/file/25e718585c6b1307cb2bf.jpg"
 global.buttonImage = "https://telegra.ph/file/adca24420fd2149a70350.jpg"
//==============================================
//ini adalah menu
global.cmdGc = [
"antitoxic","antilink","antilinkv2","kick","simi","antitekspanjang","hidetag","cekasalmember","setppgc","opentime","closetime","linkgc","linkgroup","listoneline","getpp","getbio","listgc"," listgroup","infogc",
]
global.cmdOwner = [
"join","autokirim","restart","shutdown","mulaiulang","addprem","delprem","listprem","chat","addsc","listsc","delsc","bcsc","send","backupsc","sendsc","reactowner","welcome","panelmenu","everyone","getcase","getcase2","bug","button","ban","listban","delban","addlimit","dellimit","setppbot","addmoney","delmoney",
]
global.cmdPanel = [
"panel","listusr","delusr","listsrv","delsrv","ramlist","addusr","addsrv","crateadmin","addpanel","listpanel","delpanel","1-10gb",
]
global.cmdFun = [
"family100","afk","kuismath","tebak gambar","tebak kata","tebak kalimat","tebak lirik",
]
global.cmdBug = [
"flower","bug","element","0001","temp-ban","spamsms"
]
global.cmdDownload = [
"play","ytplay","tiktok","tiktokvideo","tt","yt","ytmp3","youtubemp3","ytmp4","youtubemp4","mediafire","yts",
]
global.cmdAi = [
"ai","simi","aimg","ai-img",
]
global.cmdMain = [
"bego","tolol","pinter","pintar","asu","bodoh","gay","lesby","bajingan","jancok","anjing","ngentod","ngentot","monyet","mastah","newbie","bangsat","bangke","sange","sangean","dakjal","horny","wibu","puki","pantek","pinterest","pin","sticker","s","stickergif","sgif","ping","botstatus","statusbot","reqfitur","req","getidgc","getid","toimg","toimage","qc","totalfitur","emojimix","pixiv",
]
global.cmdConvert = [
"remini","hd","jadihd","removebg","imagenobg","remove-bg","tourl","styletext","style",
]
global.cmdTool = [
"jarak","distance","ttp",
] //tool
global.cmdSearch = [
"anime","gituub","spotify","spotifysearch","infogempa","yts","play","pixif","pin",
] //search global
global.cmdPhoto = [
"shadow","write","romantic","burnpaper","smoke","narutobanner","love","undergrass","doublelove","coffecup","underwaterocean","smokyneon","starstext","rainboweffect","balloontext","metalliceffect","embroiderytext","flamingtext","stonetext","writeart","summertext","wolfmetaltext","nature3dtext","rosestext","naturetypography","quotesunder","shinetext",
] //menu phhotoexy
global.cmdBuy= [
"buysc","tokoh","belisaldo","addsaldo","acc","buypanel","buyprem","buyscbugv1","buyscbugv2","buyscbugv3","buylimit",
]
global.cmdPrim = [
"nomerhoki","zodiac","zodiak",
]
global.cmdAnim = [
"akira","akiyama","anna","asuna","ayuzawa","boruto","chitanda","chitoge","deidara","doraemon","elaina","emilia","asuna","erza","gremory","hestia","hinata","inori","itachi","isuzu","itori","kaga","kagura","kakasih","kaori","kaneki","kosaki","kotori","kuriyama","kuroha","kurumi","madara","mikasa","miku","minato","naruto","natsukawa","nekohime","nezuko","nishimiya","onepiece","pokemon","rem","rize","sagiri","sakura","sasuke","shina","shinka","shizuka","shota","tomori","toukachan","tsunade","yatogami","yuki",
]
global.cmdRpg = [
"cekmoney","money","ceklimit","limit","buylimit",
]
global.cmdSound = [
"sound1","sound2","sound3","sound4","sound5","sound6","sound7","sound8","sound9","sound10","sound11","sound12","sound13","sound14","sound15","sound16","sound17","sound18","sound19","sound20","sound21","sound22","sound23","sound24","sound25","sound26","sound27","sound28","sound29","sound30","sound31","sound32","sound33","sound34","sound35","sound36","sound37","sound38","sound39","sound40","sound41","sound42","sound43","sound44","sound45","sound46","sound47","sound48","sound49","sound50","sound51","sound52","sound53","sound54","sound55","sound56","sound57","sound58","sound59","sound60","sound61","sound62","sound63","sound64","sound65","sound66","sound67","sound68","sound69","sound70","sound71","sound72","sound73","sound74","sound75","sound76","sound77","sound78","sound79","sound80","sound81","sound82","sound83","sound84","sound85","sound86","sound87","sound88","sound89","sound90","sound91","sound92","sound93","sound94","sound95","sound96","sound97","sound98","sound99","sound100","sound101","sound102","sound103","sound104","sound105","sound106","sound107","sound108","sound109","sound110","sound111","sound112","sound113","sound114","sound115","sound116","sound117","sound118","sound119","sound120","sound121","sound122","sound123","sound124","sound125","sound126","sound127","sound128","sound129","sound130","sound131","sound132","sound133","sound134","sound135","sound136","sound137","sound138","sound139","sound140","sound141","sound142","sound143","sound144","sound145","sound146","sound147","sound148","sound149","sound150","sound151","sound152","sound153","sound154","sound155","sound156","sound157","sound158","sound159","sound160","sound161",
]
//==============================================  
global.versionsc = 'V6' //ini versi tidak penting
//==============================================
global.domain = '_' // Isi Domain Lu
global.apikeypanel = '_' // Isi Apikey Plta Lu
global.capikey = '_' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
//==============================================
global.idsaluran = "120363259883647670@newsletter" //id saluran
//==============================================  
global.welcome = true //true untuk aktif / false untuk nonaktif
global.bugOne = true
global.button = true
global.autokirim = false
global.antitagowner = true
//==============================================  

global.mess = {
    success: '`✓ 𝘴𝘶𝘤𝘤𝘦𝘴`',
    admin: '👥 ғɪᴛᴜʀ ᴋʜᴜ𝘴ᴜ𝘴 ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ!',
    botAdmin: '📣 ʙᴏᴛ ʜᴀʀᴜ𝘴 ᴍᴇɴᴊᴀᴅɪ ᴀᴅᴍɪɴ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ!',
    owner: '❌ ғɪᴛᴜʀ ᴋʜᴜ𝘴ᴜ𝘴 ᴏᴡɴᴇʀ ʙᴏᴛ!',
    group: '👥 ғɪᴛᴜʀ ᴅɪ ɢᴜɴᴀᴋᴀɴ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴅɪ ɢʀᴏᴜᴘ!!',
    private: '👤 ғɪᴛᴜʀ ᴅɪ ɢᴜɴᴀᴋᴀɴ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ 𝘴ᴀᴊᴀ!!',
    bot: '♻️ ғɪᴛᴜʀ ᴋʜᴜ𝘴ᴜ𝘴 ᴘᴇɴɢɢᴜɴᴀ ɴᴏᴍᴇʀ ʙᴏᴛ',
    wait: '_[ ⌛ ] ʟᴏᴀᴅɪɴɢ ᴋᴀᴋ..._',
    endLimit: '🕛 ʟɪᴍɪᴛ ʜᴀʀɪᴀɴ ᴀɴᴅᴀ ᴛᴇʟᴀʜ ʜᴀʙɪ𝘴 ᴀᴋᴀɴ ᴅɪ ʀᴇ𝘴ᴇᴛ 𝘴ᴇᴛɪᴀᴘ ᴊᴀᴍ 𝟷𝟸',
    nsfw: '🔞 The nsfw feature has not been activated, please contact the admin to activate',
    ngebug: '❗Tunggu Sebentar, Pengiriman Bug Ini Akan Memakan Waktu Yang Lumayan Lama🕙',
    premium: '❌ khusus premium, silahkan ketik owner untuk mendapatkan premium',
    gc: '_👋 Penggunaan bot hanya dapat di group saja silahkan klick link dinsini > [ https://chat.whatsapp.com/EKdpcTqCiYOFOEotb91Mzt ]_',
    ban: '_[ 🔴 ]Kemu telah di ban oleh owner_',
    limitCon: '_[ ⚡ ]Limit kamu sudah habis, silahkan bermain untuk mendapatkan limit_\n_Silahkan bermain game untuk mendapatkan limit_',
    fun: "FunGame"
}
//\n_Atau tunggu sampe jam 23:00_
global.unic = {
n1: '🍻°⃟૰𝐤𝐢𝐥𝐥𝐞𝐫 -!𝐭𝐡𝐞𝐳𝐞𝐭𝐬𝐮𝐛𝐨𝐱𝐲𝐠𝐞𝐧🍺ꢵ',
n2: `💔'҉༑⃟𝐓𝐇𝚺͢𝐙̸𝚺𝐓𝐒̸𝐔𝐁𝟎̸͢𝐗𝐘𝐆̸𝚵𝐍❤️‍🩹`,
n3: '*👀⃟༑𝐓𝐇𝚺͢𝐙̸𝚺𝐓𝐒̸𝐔𝐁𝟎̸͢𝐗𝐘𝐆̸𝚵𝐍༑⃟♥️*',
n4: '𝐙𝚺͟𝐓𝐒𝐔𝐁𝚶𝐗͟𝐘𝐆 😈̸̦̣͛͘ removed gay ♣️_🌈̞⃜ ...~',
n5: '༑❄️͜͡•°𝐙͟𝚺𝐓͟𝐒𝐔𝐁͟𝚹꫰𝐗̷𝐘͜𝐆̚𝚺𝐍༐🥶𖫰᷍҉ํ⃟ৣ ̭ • anti plastik 🧊ꫬ—𝅨🌊̨̈ꨲꪾ …',
n6: '*🦠 ༑̶ 𐎟⃟ 𝐙𝚺𝐓𝐒𝐔𝐁𝚹𝐙𝚹𝐢𝐂 𐎟⃟ ༑̶ 🦠',
n7: '❬༑⿻⃟⭐᪾ᩭ𝐙𝚺𝐓𝐒𝐔𝐁𝛀 ✶ 𝐙𝚹𝐢𝐂༑🔥⃟᪾⿻❭༉'
}

global.jpegT = '/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAdAAAABwEBAQAAAAAAAAAAAAAAAgMEBQYHCAEJ/8QAOxAAAgEDAwIDBQUFCAMAAAAAAQIDAAQRBRIhBjETQVEHFCJhcQgjMkKBFZGhsdEWJDNSU3KSwUNUwv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAAEEBQb/xAAjEQACAgIDAAICAwAAAAAAAAAAAQIRAyEEEjEiURNBFCNx/9oADAMBAAIRAxEAPwDD9QsxBLEqMHXYO2OPWjrEsFqjozBQTub0PkfpUhqLq1gx93Yo3xpIDgqc/wAjVbmuXfemRn8QxXTnKMWYoJyQ6k8EclSWByHTjv6im3jSiVikm4uMEA9x86ZPcu6gOxVl7GiOfFO/ftfzx51lnkT8NEYsslj1FLEiQX8XjxKezHay/Ru4qfXr2/ayktppVuLTbtRLkbnA8hvHf9azsvI2BNuYDgEdxXu/wwCkn1BFJeWQaxoV1uKOeRrm3Coc8oOcVCRSFJMjsT2p7LMdreQPfHamMqgYZWDA+nlS7CoVnIDBl7g0k77qKWJA5ryoQOrYwTT6N8rGQe4qNqRjUCNMeQokCxXO+P59qaoDG+cU4TABB4pGSZOxy2KIg8jlRNu/lSeauOhpGFT3fBLd8HnFUSBg0ijIIz2NWW1tJpCnh5UH8xbitfFk09IxcqNr0vwESeG8R5HBANdc9C6kup9KabchgSYgrc+Y4NcbaHEqIYXJfHnuz+tbB0F15/Z/QfcJQX2ysynk8ED/ALzW/k4nmgq9Obx8y4+R34c9aXrKSQJa3i5txxjzAqJ1ZI4Jm933eF5Z71FJ4oAbAYVK2ty8u3KoAvyzXK7OSpnbUVF2iKlYN5k+lESTb3/fUnqVgYlE0bKynuAe1RPiHbtI/hSJpxdMbFp7HSv8Ab50sIPFQMWwD5YqOWQqMAClF1J4xtCKQKEOxV7QEkbuKYy27J25FLm+cnOxead7A0YYnGRmoUQ+DXlT2n2Au5AgUvn/ACij6noLWblW4Yd+OBUsvqyBVMgk9hT+2H3EYz8TkjFJtZyj4U+LHJxU30505eapeRoqlFxkMRxVpg9WyG8N33g8DNFt7XxrhIoyWcnGMVp+odFiztTKDuGCXOOMirB7EehGvb6S+u4lMacruGeSOKjYyOJsxe+02awJ8dCBu2g+tTPT94XWRSpwoGMnNbP7cugLO1trK7jupg00zZQKoA4HasgOnJpP+FI0nid9w7YpvHk1kQrk4P62yzaLMXDHGNpx+lTYkB7bj9Kpmm37wo4CKcnzqyWt0rwKznBI7V3cU00edz4mpWZhp0ylWU5wADgnvUxaRRyn7kGJn4GQCDVdtPvSBkBx2JrR+l7aK7USCLwnj+GVTyrHHcelcCOVx9PRrF3dFTvoZkfZJHHz+YGo+e2Qyc5z8q6A0HofRdctXudQilaUPsGyQqMY9BR7z2YdNrMQIbnGP9c0OR9tobHC1o5xkhCuQCcU0kXDtXUtl7IOk7i2WSW3uy5znFww86jrv2R9KJcyKtvdYB/9g0BawtujnBYVKg5PapRB8CgLu47ZrpC39jXSDQRsbe8yVBP95b0qia97MrS1vnlRporFM7U3bmIHzNU5UEsEmULQZI4rkC4bbFyWWIZJ49fKlL24k1S7NvaRERb/ALtByf1Pmam7XQo7rUDbWMRSAZBc96m4r7QuhSWmhF3f4BRB5H1PpQ9/0hiwtbl4T3RPsr2acb7WykcRG4o5xj9aN1Fq9po040/pyw95lGBvZSAD6D1qr2HXGudcdZaLY3KOtg9xGnucRwrDPJOOTxXVl90xpURt0itYlMQynHK05K1YtTXakYX0h0trPUhJ1lniRyCVUY49K3bp/p+30vEdrGEiCheB3wKkdPsUhwVA4+VSsaAdhQpBTy3pFM686N07qSztYb+W7RYnLr4LqDkjzyprA/bB0PpnTg033Ca8czb93jOpxjHbCj1rqfUEDImfWufvtNsbdNB8LjcZc55/y0/BX5FZk5MpPE0mYebdYeELHPPNLx3SogDbgflSFvKZQWmIwppC5dhO4AUjPHeuopV4cir1Iq2jwmWbPkuDmtE6XmkSG4KsclgT+6s0tZZIs+G5XPfFPoNUvrcEQ3MiA8nBrippenZTa8Ok+hrqYaXIA/8A5T5D0FXfTreK6thLOu9ySM5I/lXL/TfUesRWTrHqEyjeexFa/wBB61qNxoCPPdyO+9hk49aias0KVxL7czSWszQwNtjXsO/86kLWzguIElmTdI4yxyRmss1vV79dSlAupAOPT0FX/pu6mk0KyeSRmYx5JPnVN2NXllvgtIBDGAnAUDufSoLqmxgn04xsgxggY71Z7MA2kJPJKKf4UtJpq3CcICPSqa0Ap0zAptJ/Z0Di1QmUkgKKnul/Z309reiq2v2rzzTnxPHUlWX5A/8AVatD0/axszPEMnzIpeWxidVjUBY14AUYoYxp2HPKprqUzpDorpXpDU2uNEtJJb7G1Z7l95QfLyFXmDMsvcvI3djXlnpVrHKp8Pcc+ZqaitoUIKxgEelMtmeTjHw9tk2gKacbRXigA0ZqiFN2Nr0Dav1rA/tMQpIug71zgy+f+2tz1iRkjjKkjmudftO3UyroO2QjmX/5p2FqM02Lzq8TSMbnVYmCIp2sOQPM0jEUVMPG7t60lay3B++ZgQp/N/1T6KWdlyqrg+tdSLUtnIm2tGeZI7GnVp8StnnmiWoHxZFTuixho5MIG+L0zXH62rOwncupY+ioIn0yQvGrHxDyR8hVmiuZbVPDt5XiTvtRsCo3ppNlk427fj9MeVVnrA3I1l/BMwXYv4M47UThUbDjlqXWi9+LNKS7u7sfMnNXLR7q5TTLdVnlUBewY1cfYLZ203sr0d7y2hknJm3NLGCx++fGSee1XG4srYTOEtoQoPAEYxQSWjTiy78D6IzNo1gzEljbxkk+fwirlboohTCgfCP5VE2karawgIoARRjHyqYjPwL9KoTNgKKTyoP6V54UX+mn7qVwMUjKcRv9DUaoBbDeGg5CqD9K9JqFupGFvJh2zjyNQzTS4/xJP+RoHKh0cLl+y5g17IcLVKjnlD8yvj/caT1G6ZIQTcFee5fFWpWF/HafpVftHanfaboekPp95PbM9w4YxSFSRtHfFcydUatqGpe7/tC9uLrZnb40hfb27ZrTPtN3rPoWjBLlm/vD9nz+UVzuZpT3kc/VjRwlTsRmh7Et9k8bwbXcjbyBTtbgED4jVLhu5IzwTSnv8g7E/vrbHlpKqOdLitsRnGCMVoHstnt4bK9FzLFGTIMb2A8vnVKmTHI7U0mRnI2gn6Vna6uzXjmb5FC16PEsY2njHBaFdwz6ZFaT0Npsn7CXxrNt+9vxxc9/pVK+zd1Ho2i9F3dvq2pWtnO14zhJpApI2rzXQ/TOq6fqmmLc6ddw3NuWIEkbZGR3oH9mpZNFQW1mjUKkEiqOwCECrnpEbDTbcOhDbecjmpZCGGVORRhQFTydlQgq4A4r0SIPzr++jEjNQEkbmVzsP4j5VAUrLQe1M58+C/0NLh12/iFJTsBC/Pkav0kdEGMmvLkfdNxR/FjHJdQKTuru3EDZmT99LaNdOyF1ghbIk8fEOayH20XAXpmArLt+/HZseRrUOqry3OkMBMn4186wX24zxSdLQCN1Y+8DgH5GgrdGhtxxtmT9Qz+LDEDLvwx43ZxUDQoU1KjmTl3dgoUKFWAS0oDL8DZ+VJRMI8hziknaVDuIHHejP/eIwUHI8qf2szKNe+BpVMrboxuHbIrpf2Bda9OdPez6Kx1nVre0uxcSuYpN2cE8HgVzdZKY4iG4OaNLIobBNTqqtkU3F0j6D9N9Q6ZrNkkum3LTxEbhIInVCPUMQAacSa5ZpAJVZnBbbhV57Zzj0xWd/Z51P9s+xq3iRt0toZrM/UcqP+LrUtDGTrEMq7jE1qQR+XIYfx5NJfpuww7rZdbi4CCFkKssvIPyqE1PW7TQ9Ol1DX7qK0tEfDSsDtUE4XOP0oWHimwi2uu8ZjBfnCqSAB+6q17UrBNY6E6ksZJGaVrR2ijzwWUb1OP9yiqDUOqJOH2jdIyyIkeu2jO5AUDdyT+lWa5uYRbSZkH4TXBuma1Yw39pJJLhEkVmO08AEV0rc+2XolreRV1RiSpA+4f+lFQMWr2y53mo2kdrI8k6qqrkk+VV291/Snt2Vb2Ik+XP9Ko8/tE6a1eF9Psb4yXVwPDjTw2GWPlnFQeqkaXYyXd793BH+Ju+Kz5E70jr8eOKSuUi0dV67pkOkM0l5Gq7155rHPaRrOnahokcVldJNIJQSq57YNF6w6l0rUNFaC0uN8pdTjaRwKz64kV0AU5OaqEW3bEczPFXCDtNDahQoU85IKFChUITLJvXJ7U0aFoW3xdvMUf3ho3w44PmKUEqN2YVpdSMi7R/wEcoYAjt5/Kk7hSz5HavJYypLx9/MetHikEsfzHcUN3pl1XyR0N9lTqP3HRuqNLaRVcNFcwAn8zfA38krTrXV/HGoQ2fvBe0XKoIzlyDzye+T5VzN7DbmWDryK2i2b7yF4lLnADD4h/FRXU63n3Do9zHa3Y7pPxg/wAMj5ilS9OpxEutnmh6nKIVOoW3uiSs2YbiVTtJ5yD8+eDT6L3YP4dtEkiSH4lQfCf61AaXN7tG11rd9BJHAxxOQFUljjj5D1/pTO/9o/RWh3Fx7zrVvKSNwS0YzHd5j4MgfrihpsPJUd2ch9S6S+l9QalZBcLb3Ekag/5Qxx/DFRZcEEDvVu9ous6drfV+oahpIlFtcMGHiLtOcAHjPyqpeAwG7I45plfRzrtux/0xdxaZ1Bp97c7vBgmV32jJwPStE63680bWOmruxszc+PIBt3x4HBHzrKgd/AoeCx8xQ19DY5HFUI0KUeJkXJxik6pqgU78BQoUKosFChQqEJUtFMMdm+Yps+1W2yJ+opdjRc5GDzWh7MsdHkbL2V8ik5VKMHTv50SdAnK5Bo9vIzAhuaC/0HVfJEno2qXOk6naanp7BLq3YSRsRkA1O617U+sNUytzrEsan8sKhB/Cqlbnl18hSNyBmpL7CxycfimPrnUrzUCHvbu4uW9ZZC/86bsfSm8BO7FODVp2gZKmEYUVXIbax4NHpOUcfSqZa3oTT4JseVLM+350hL3B86M/4B9KFOg2roEswdNuMUjS8USvC7knINIULdhJV4ChQoVRYKFChUIf/9k='

global.limitawal = {
    premium: "Infinity",
    free: 20
}
//==============================================

//TELEGRAM BOT
global.OWNER = ["Yudha", "http://t.me/Xiilya_bot"]
global.TOKEN = '7401534762:AAGeV3oqMUwFcVluONvN7rCkzGYinpIQ8I8'

//==============================================

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})